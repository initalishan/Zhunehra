import time
start_time = time.time()