from telethon import Button

download_buttons = [
    [
        Button.inline("Video", data=b"mp4"),
        Button.inline("Audio", data=b"audio")
    ],
    [
        Button.url("Subscribe To Zhunehra", "https://t.me/zhunehra")   
    ]
]