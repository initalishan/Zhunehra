from telethon import Button 

subscribe = [
    [Button.url("Subscibe To Zhunehra", "https://t.me/zhunehra")]
]